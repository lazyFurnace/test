import React from 'react';

import Row from './row';
import Block from './block';

const layout = {
  row: 10,
  column: 10,
  thunder: 5
}

export default class Minesweeper extends React.Component {
  createLayout = (layout) => {
    const layoutArr = [];
    for (let row = 0; row < layout.row; row++) {
      layoutArr[row] = [];
      for (let column = 0; column < layout.column; column++) {
        layoutArr[row][column] = {
          thunder: false,
          flag: false,
          pass: false,
          num: 0
        }
      }
    }
    return layoutArr;
  }
  initLayout = (layout) => {

  }
  render() {
    console.log(this.createLayout(layout));
    return (
      <div>
        111
      </div>
    )
  }
}
