import React from 'react';

export default class Block extends React.Component {
  render() {
    return (
      <div>
        block
      </div>
    )
  }
}